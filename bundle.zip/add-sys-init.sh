#!/bin/bash
LOCAL_PATH=$(cd `dirname $0`; pwd)
cd ${LOCAL_PATH}

function add_sys_init(){
sudo apt-get install chkconfig
 chkconfig --add launch.sh
 chkconfig launch.sh on
}
add_sys_init

#echo '是否开机自启动？[y]/n'
#
#read input
#
#if [[ !${input} ]];then
# add_sys_init
#elif [[ ${input} = 'y' ]];then
# add_sys_init
#elif [[ ${input} = 'n' ]]; then
#""
#else
#echo "请输入y或n"
#fi


